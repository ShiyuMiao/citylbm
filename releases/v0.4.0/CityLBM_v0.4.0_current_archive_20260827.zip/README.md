<p align="center">
  <img src="assets/branding/citylbm-readme-icon.png" alt="CityLBM application icon" width="144">
</p>

<p align="center">
  <img src="assets/branding/citylbm-readme-header.png" alt="CityLBM - Urban Wind Simulation" width="960">
</p>

<p align="center">
  <strong>面向设计流程的城市风环境模拟工具</strong><br>
  <em>Design-oriented urban wind simulation workflow</em>
</p>

<p align="center">
  <a href="#中文">中文</a> | <a href="#english">English</a> | <a href="LICENSE">MIT License</a>
</p>

## 图标目录

CityLBM 的 README 主图标和组件图标集中如下。主图标的可编辑 Draw.io 源文件位于 [`assets/branding/citylbm-app-icon.drawio`](assets/branding/citylbm-app-icon.drawio)。下列图标是当前仓库随附的界面资源目录，不单独构成组件可用性或验证完成的声明。

| 场景与输入 | 仿真与数据 | 可视化与分析 | 工作流辅助 |
| --- | --- | --- | --- |
| <img src="src/Resources/Icons/CreateScene.png" width="42" alt="Create Scene"><br>Create Scene | <img src="src/Resources/Icons/RunSimulation.png" width="42" alt="Run Simulation"><br>Run Simulation | <img src="src/Resources/Icons/ReadVTK.png" width="42" alt="Read VTK"><br>Read VTK | <img src="src/Resources/Icons/validation.png" width="42" alt="Validation"><br>Validation |
| <img src="src/Resources/Icons/AddBuildings.png" width="42" alt="Add Buildings"><br>Add Buildings | <img src="src/Resources/Icons/SimulationStats.png" width="42" alt="Simulation Stats"><br>Simulation Stats | <img src="src/Resources/Icons/VelocityVisualization.png" width="42" alt="Velocity Visualization"><br>Velocity View | <img src="src/Resources/Icons/Lawson.png" width="42" alt="Lawson"><br>Lawson |
| <img src="src/Resources/Icons/WindCondition.png" width="42" alt="Wind Condition"><br>Wind Condition | <img src="src/Resources/Icons/GridGenerator.png" width="42" alt="Grid Generator"><br>Grid Generator | <img src="src/Resources/Icons/VTKCloudVisualization.png" width="42" alt="VTK Cloud"><br>VTK Cloud | <img src="src/Resources/Icons/DataProbe.png" width="42" alt="Data Probe"><br>Data Probe |
| <img src="src/Resources/Icons/DomainSetup.png" width="42" alt="Domain Setup"><br>Domain Setup | <img src="src/Resources/Icons/AbsoluteDomain.png" width="42" alt="Absolute Domain"><br>Absolute Domain | <img src="src/Resources/Icons/SliceVisualization.png" width="42" alt="Slice Visualization"><br>Slice View | <img src="src/Resources/Icons/Streamlines.png" width="42" alt="Streamlines"><br>Streamlines |
| <img src="src/Resources/Icons/DomainDesigner.png" width="42" alt="Domain Designer"><br>Domain Designer | <img src="src/Resources/Icons/WindSpeedGrid.png" width="42" alt="Wind Speed Grid"><br>Wind Speed Grid | <img src="src/Resources/Icons/VerticalSlice.png" width="42" alt="Vertical Slice"><br>Vertical Slice | <img src="src/Resources/Icons/Isosurface.png" width="42" alt="Isosurface"><br>Isosurface |
| <img src="src/Resources/Icons/SceneInfo.png" width="42" alt="Scene Info"><br>Scene Info |  |  |  |

---

<a id="中文"></a>
## 中文

CityLBM 是一个面向 Rhino/Grasshopper 设计流程的城市风环境模拟工作流。它连接场景定义、FluidX3D 案例生成与外部求解、VTK 结果读取和 Rhino 内可视化，使研究人员能够在同一参数化环境中组织可追溯的风环境案例。

### 当前可展示的成果

- **可运行的工作流原型**：从 Grasshopper 场景与建筑输入，到 FluidX3D 案例文件、VTK 输出和 Rhino 结果查看。
- **AIJ Case A/E 复现资产**：包含案例文件、`setup.cpp`、坐标/尺度元数据、点位结果表和工作流截图；v0.2.0 包用于复现与检查。
- **v0.3.0 验证就绪性改造**：风速与 `k` 剖面输入、元数据记录、时间平均、点位/归一化/几何尺度审计，以及原生 FluidX3D 基线预检和自动验证门禁。
- **可追溯实验链**：验证脚本与指标模板支持保存运行元数据、探针结果、哈希和门禁报告。

### 验证状态

项目处于积极开发阶段。现有 AIJ Case A/E 资产证明端到端工作流和诊断能力；其中短步数 smoke run 与诊断结果不应被解释为论文级精度验证。正式准确性结论仍需要严格原生基线、入口和边界条件证据、充分时间平均以及网格收敛记录。

v0.3.0 的交付边界见 [`docs/v0.3.0_validation_ready_status.md`](docs/v0.3.0_validation_ready_status.md)：它是验证就绪版本，不是已经完成的 Case A/E 论文级精度结果。

### v0.4.0 当前封装记录

v0.4.0 封装当前 Rhino 7 / Grasshopper 验证分支成果，停止继续向论文级精度优化推进，保留已形成的代码、脚本和诊断证据。该版本的重点是把 CityLBM 的案例生成、原生 FluidX3D 基线预检、VTK 输出完整性检查、入口剖面审计、边界审计和测点误差统计组织成可追溯工作流。

- 插件元数据、Yak manifest 和程序集版本统一为 `0.4.0`。
- Case A 已完成 full AF 表格输入的代码生成校验，`AF_caseA.csv` 的 24 行 `z, U, k` 被写入生成的 FluidX3D `setup.cpp` 和元数据。
- 原生 FluidX3D Case A 300/150 诊断跑产生 2 个完整 VTK 帧，并完成 186 个官方测点的后处理审计；随后新增 `VTK Save Start=100` 的短 canary，验证保存调度可产生 `[100, 250, 300]` 三个完整 VTK 帧。
- 当前诊断指标仍不作为发表级精度结论：`R2=-2.8714`，`Pearson=0.0163`，`RMSE ratio=3.4374`，主要阻塞包括步数/平均不足、入口 `k` 运行保持不足、边界协议证据不足和 native preconditions 未通过。
- 最终封装检查点：停止继续精度优化后，保留 runtime inlet diagnostics、native/CityLBM parity 和 boundary runtime window 门禁补强；相关 smoke 测试用于证明发布脚本链可执行，不构成新的 CFD 精度结论。
- v0.4.0 用户包可直接安装 Grasshopper 插件并生成案例；真实模拟仍需要用户在 `Run Simulation` 中指定本机可用的 FluidX3D 源码或求解器环境。
- 2026-08-26 最终归档：本仓库保留当前 v0.4.0 封装成果并停止继续精度优化；后续论文级 Case A/E 精度结论应基于新的独立验证分支或运行记录追加，而不是覆盖本记录。
- 2026-08-27 GitHub 上传检查点：追加 RMS/k 速度替代入口门禁，明确当前随机 RMS/k 扰动不能作为真实数字滤波、SEM 或 precursor/recycling 湍流入流证据；该补丁是证据边界收紧，不是新的精度优化。
- 2026-08-27 main 分支归档：将当前 v0.4.0 成果作为 GitHub `main` 上传基线追加记录，旧版本记录与旧发布目录保留，不作为本次封装删除或覆盖。
- 2026-08-27 最终补充封装：追加坐标/测点投影、边界源、入口源和 native preconditions 的脚本级门禁，保留为 v0.4.0 证据链补强；该记录不新增 CFD 精度结论，也不删除历史 v0.2.0/v0.3.0 记录。
- 2026-08-27 停止优化封装：按当前成果冻结 v0.4.0 发布线，补齐生成案例运行元数据中的 `CityLBMVersion=0.4.0`，重新打包并上传 GitHub；后续精度优化转入新分支或新版本记录。
- 2026-08-27 当前成果归档：纳入入口合成涡中心持续平移/回卷的代码生成修复与 smoke 覆盖，作为 v0.4.0 冻结成果上传；该项仍属于入口证据链补强，不宣称 AIJ Case A/E 精度已经达到论文发表标准。

### 快速开始

1. 按 [`INSTALL.md`](INSTALL.md) 将 `CityLBM.gha` 及其依赖安装到 Grasshopper Libraries 目录。
2. 在 Rhino/Grasshopper 中使用 `Create Scene` 和相关场景组件生成案例。
3. 使用 `Run Simulation` 指向完整的本地 FluidX3D 源码或可执行环境；仅生成案例可使用 `Mode 0`。
4. 使用 `Read VTK` 与可视化组件读取输出。严格 AIJ Case E 流程见 [`docs/CaseE_run_protocol.md`](docs/CaseE_run_protocol.md)。

### 构建

```powershell
dotnet build -c Release
```

Release 构建产物位于 `bin/Release/CityLBM.gha`。当前开发分支为验证就绪性迭代，不应替代经审核的正式发布包。

---

<a id="english"></a>
## English

CityLBM is an urban wind-simulation workflow for Rhino and Grasshopper. It connects scene definition, FluidX3D case generation and external execution, VTK result reading, and in-Rhino visualization so that wind-environment cases can be organized in one traceable parametric workflow.

### What Is Available

- **Runnable workflow prototype**: Grasshopper scene and building input through FluidX3D case files, VTK output, and Rhino result inspection.
- **AIJ Case A/E reproduction assets**: case files, `setup.cpp`, coordinate and scale metadata, probe-result workbooks, and workflow screenshots. The v0.2.0 package is intended for reproduction and inspection.
- **v0.3.0 validation-readiness work**: velocity and `k` profile input, metadata capture, time averaging, probe/normalization/geometry-scale audits, native FluidX3D baseline preflight, and automated validation gates.
- **Traceable experiment chain**: validation scripts and metric templates support run metadata, probe outputs, hashes, and gate reports.

### Validation Status

CityLBM is under active academic development. Existing AIJ Case A/E assets demonstrate the end-to-end workflow and diagnostic capability. Short smoke runs and diagnostic outputs are not publication-grade accuracy validation. Final accuracy claims require a strict native baseline, inlet and boundary evidence, adequate time averaging, and documented grid convergence.

See [`docs/v0.3.0_validation_ready_status.md`](docs/v0.3.0_validation_ready_status.md) for the v0.3.0 delivery boundary: it is validation-ready, not a completed Case A/E publication-grade accuracy result.

### v0.4.0 Packaging Record

v0.4.0 packages the current Rhino 7 / Grasshopper validation branch and stops further accuracy optimization in this release line. It preserves the current code, scripts, and diagnostic evidence as a traceable workflow rather than presenting the short diagnostic runs as publication-grade validation.

- Plugin metadata, Yak manifest, and assembly versions are unified as `0.4.0`.
- Case A full-AF code generation was verified: all 24 rows from `AF_caseA.csv` are emitted into FluidX3D `setup.cpp` and metadata.
- A native FluidX3D Case A 300/150 diagnostic run produced 2 complete VTK frames and completed post-processing for 186 official probe points; a later `VTK Save Start=100` short canary verified the `[100, 250, 300]` three-frame output schedule.
- The current diagnostic metrics are not publication-grade: `R2=-2.8714`, `Pearson=0.0163`, `RMSE ratio=3.4374`. Remaining blockers include insufficient run length/averaging, incomplete runtime preservation of inlet `k`, insufficient boundary protocol evidence, and failing native preconditions.
- Final packaging checkpoint: after stopping further accuracy optimization, v0.4.0 preserves the hardened runtime inlet diagnostics, native/CityLBM parity, and boundary runtime window gates. The related smoke tests confirm the release-script chain, not new CFD accuracy.
- The v0.4.0 package can be installed directly in Grasshopper and can generate cases. Real solver execution still requires a local FluidX3D source tree or executable environment to be configured in `Run Simulation`.
- Final archive on 2026-08-26: this repository preserves the current v0.4.0 package and stops further accuracy optimization in this line. Future publication-grade Case A/E claims should be added from a new independent validation branch or run record instead of overwriting this record.
- GitHub upload checkpoint on 2026-08-27: the RMS/k velocity-surrogate inlet gate was added, making clear that random RMS/k perturbations are not evidence of a true digital-filter, SEM, or precursor/recycling turbulent inflow. This is evidence-boundary hardening, not a new accuracy optimization.
- Main-branch archive on 2026-08-27: the current v0.4.0 state is appended as the GitHub `main` upload baseline. Earlier version records and release directories are preserved rather than deleted or overwritten by this package.
- Final supplemental package on 2026-08-27: script-level gates for coordinate/probe projection, boundary source evidence, inlet source evidence, and native preconditions were appended as v0.4.0 traceability hardening. This record adds no new CFD accuracy claim and preserves earlier v0.2.0/v0.3.0 records.
- Stop-optimization package on 2026-08-27: v0.4.0 is frozen from the current state, generated-case runtime metadata now records `CityLBMVersion=0.4.0`, and the package is rebuilt and uploaded to GitHub. Later accuracy work should continue in a new branch or version record.
- Current-result archive on 2026-08-27: the generated-code fix for persistent synthetic-eddy center advection/wrapping and its smoke coverage are included in the frozen v0.4.0 upload. This remains inlet-evidence hardening and does not claim publication-grade AIJ Case A/E accuracy.

### Quick Start

1. Follow [`INSTALL.md`](INSTALL.md) to install `CityLBM.gha` and its dependencies in the Grasshopper Libraries directory.
2. Create a case with `Create Scene` and the related scene components in Rhino/Grasshopper.
3. Point `Run Simulation` to a complete local FluidX3D source tree or executable environment. Use `Mode 0` for case generation only.
4. Read outputs with `Read VTK` and visualization components. See [`docs/CaseE_run_protocol.md`](docs/CaseE_run_protocol.md) for the strict AIJ Case E workflow.

### Build

```powershell
dotnet build -c Release
```

The Release artifact is written to `bin/Release/CityLBM.gha`. The current development branch focuses on validation readiness and is not a substitute for a reviewed release package.

## License

Released under the [MIT License](LICENSE).

## Author

Shiyu Miao, Dalian University of Technology<br>
miaoshiyu@mail.dlut.edu.cn
